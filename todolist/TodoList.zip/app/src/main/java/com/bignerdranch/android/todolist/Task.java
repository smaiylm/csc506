package com.bignerdranch.android.todolist;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.content.ContentValues.TAG;

/**
 * Created by Smaiyl on 1/22/2018.
 */
/*
public class Task extends AppCompatActivity {
    private Button mDoneButton;
    private TextView mQuestionTextView;
      String description;
    //write a method for each of the  booleans
        boolean starred;


        boolean done;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate(Bundle) called");
        setContentView(R.layout.activity_main);



        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);}
/*
    public boolean done() {

        int messageResId = 0;
        mDoneButton = (Button) findViewById(R.id.done_button);
        mDoneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Task.this,
                        R.string.done,
                        Toast.LENGTH_SHORT).show();


            }
        });



        return false;
    }

*/











/*



 private void checkAnswer (boolean userPressedTrue){
            boolean answerIsTrue = mQuestionBank[mCurrentIndex].isAnswerTrue();

            int messageResId = 0;


            if(mIsCheater) {
                messageResId = R.string.judgement_toast;

            }
            else {
                if (userPressedTrue == answerIsTrue) {
                    messageResId = R.string.correct_toast;

                } else {
                    messageResId = R.string.incorrect_toast;
                }


            }






            Toast.makeText(this, messageResId, Toast.LENGTH_SHORT)
                    .show();
        }



       // return false;







    }


      //  String toString(){

         //   @Override

                 //   return description;

        }





*/

