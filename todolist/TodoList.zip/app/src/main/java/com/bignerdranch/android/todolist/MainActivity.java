package com.bignerdranch.android.todolist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.DynamicLayout;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private TextView mQuestionTextView;
    private Button FloatingActionButton;
//    ArrayList<String> myStringArray = new ArrayList<String>();    //An array list containing things to display in a list
    ArrayList<String> itemList ;

    ArrayAdapter<String> adapter;
    Button addButton;
    EditText itemText;
    TextView tv;
    ListView lv;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
     //   mQuestionTextView = (TextView) findViewById(R.id.question_text_view);
        super.onCreate(savedInstanceState);

        Log.d("onCreate", "onCreate(Bundle) called");
        setContentView(R.layout.activity_main);
        lv = (ListView)findViewById(R.id.listView);
        itemText = (EditText) findViewById(R.id.addtext);
        addButton = (Button)findViewById(R.id.addbutton);
        itemList = new ArrayList<>();

        adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_multiple_choice,itemList);
      //  itemList.add("Example 1"); //Just testing 
        View.OnClickListener addlistener = new View.OnClickListener(){
            @Override

            public void onClick(View v){


//test


                itemList.add(itemText.getText().toString());    //getting user input

                itemText.setText("");
                adapter.notifyDataSetChanged();

            }





        };






        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                SparseBooleanArray positionchecker = lv.getCheckedItemPositions();

                int count = lv.getCount();

                for(int item = count-1; item >= 0; item --){

                    if(positionchecker != null && positionchecker.get(item)){
                        Log.d("Deleting an item",  "");
                        adapter.remove(itemList.get(item));  //remove the item


                        Toast.makeText(MainActivity.this, "Congratulations, you have successfully completed your to-do item!", Toast.LENGTH_SHORT).show(); //toast when completed
                    }
                }

           //    positionchecker.clear();        Clears/deletes an item in the ListView, (the app crashed when testing)
                adapter.notifyDataSetChanged();    //notifying that the ListView has changed/has had an item deleted.


                return false;
            }
        });

        addButton.setOnClickListener(addlistener);



        lv.setAdapter(adapter);
                /*

//Floating action Button


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.floating_button);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
//floating action button
// user adding a button


        removebutton = (Button) findViewById(R.id.add_button);
        et = (EditText) findViewById(R.id.editText1);
        tv = (TextView) findViewById(R.id.textView1);
        lv = (ListView) findViewById(R.id.listView1);
        m_adapter = new ArrayAdapter<String>(this, R.layout.main, m_listItems);
        lv.setAdapter(m_adapter);
        final String input = et.getText().toString();

        bt.setOnClickListener(new View.OnClickListener() {

                                  public void onClick(View v) {
                                      // TODO Auto-generated method stub

                                      m_listItems.add(new String(input));
                                      m_adapter.notifyDataSetChanged();
                                  }

        });
        */
//user input
       // itemList.add("Example 1");
       // itemList.add("Example 2");

/*
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, myStringArray);


        ListView listView = (ListView) findViewById(R.id.listView);

        listView.setAdapter(adapter);


        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);



        */
    }



/*

    private void createLayoutDynamically(int n) {

        for (int i = 0; i < n; i++) {
            Button myButton = new Button(this);
            myButton.setText("Button :"+i);
            myButton.setId(i);
            final int id_ = myButton.getId();

           // LinearLayout layout = (LinearLayout) findViewById(R.layout.linearlayout);
           // layout.addView(myButton);

            myButton.setOnClickListener(new View.OnClickListener() {
                public void onClick(View view) {
                    Toast.makeText(MainActivity.this,
                            "Button clicked index = " + id_, Toast.LENGTH_SHORT)
                            .show();
                }
            });
        }



    }
*/


}



