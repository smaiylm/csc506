package com.bignerdranch.android.todolist;

import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;

/**
 * Created by Smaiyl on 1/25/2018.
 */

public class Checkbox extends AppCompatActivity {
}
/*




    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.checkIt:
                if (checked) {
                    // Put some meat on the sandwich
                }
            else
                // Remove the meat
                break;
            case R.id.:
                if (checked)
                // Cheese me
            else
                // I'm lactose intolerant
                break;
            // TODO: Veggie sandwich
        }
    }













}
*/